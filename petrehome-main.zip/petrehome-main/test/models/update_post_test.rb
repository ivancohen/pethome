require 'test_helper'

class UpdatePostTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
