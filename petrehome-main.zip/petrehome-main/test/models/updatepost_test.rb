require 'test_helper'

class UpdatepostTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
